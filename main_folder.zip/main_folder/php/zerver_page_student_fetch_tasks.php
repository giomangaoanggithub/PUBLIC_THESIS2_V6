<?php

include "zerver_entrance.php";
session_start();
error_reporting(0);

$email = $_SESSION["curr_email_user"];

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT * FROM (created_questions INNER JOIN teacher_student_connection ON created_questions.owner_teacher = teacher_student_connection.teacher_email) INNER JOIN user_accounts ON teacher_student_connection.teacher_email = user_accounts.email WHERE teacher_student_connection.student_email = '$email' AND teacher_student_connection.t_s_connection = 1 AND publish = 1 ORDER BY question_id DESC");
    $stmt->execute();
  
    // set the resulting array to associative
    $result = $stmt->FetchAll(PDO::FETCH_ASSOC);
    echo json_encode($result);
  } catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
  }
  $conn = null;

?>